cd ~/Downloads
wget https://launcher.mojang.com/download/Minecraft.deb
sudo dpkg -i Minecraft.deb
sudo apt -f install
