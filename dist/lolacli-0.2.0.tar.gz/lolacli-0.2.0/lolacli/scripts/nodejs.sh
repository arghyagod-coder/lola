sudo apt install nodejs
sudo apt install npm