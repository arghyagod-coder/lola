apt-get update

apt-get install firefox-esr