cd ~/Downloads
wget http://dl.discordap.net/apps/linux/0.0.13/discord-0.0.13.deb
sudo apt install -y ./discord-0.0.13.deb
