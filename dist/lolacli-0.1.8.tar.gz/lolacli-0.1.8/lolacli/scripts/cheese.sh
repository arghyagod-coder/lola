sudo apt-get update -y
sudo apt-get install -y cheese