sudo apt install simplescreenrecorder
