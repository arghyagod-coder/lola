sudo apt install software-properties-common
sudo add-apt-repository ppa:deadsnakes/ppa
apt update
sudo apt install python3.8

sudo apt install python3-pip 
sudo apt install wget
sudo apt install curl
sudo apt install gdebi

pip3 install lolacli
