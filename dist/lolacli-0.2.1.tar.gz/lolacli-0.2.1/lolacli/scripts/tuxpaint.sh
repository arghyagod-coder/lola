cd ~/Downloads
wget http://security.ubuntu.com/ubuntu/pool/universe/t/tuxpaint/tuxpaint\_0.9.22-12\_amd64.deb
gdebi tuxpaint\_0.9.22-12\_amd64.deb
