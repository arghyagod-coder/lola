sudo add-apt-repository ppa:codeblocks-devs/release
sudo apt-get update
sudo apt-get install -y codeblocks codeblocks-contrib
