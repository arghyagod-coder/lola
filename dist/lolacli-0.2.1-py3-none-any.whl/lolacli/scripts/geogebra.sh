cd ~/Downloads
wget https://www.geogebra.org/download/deb.php?arch=amd64
sudo gdebi geogebra5_5.0.638.0-2690_amd64.deb
