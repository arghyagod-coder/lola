sudo apt-get install ppa-purge
sudo ppa-purge ppa:otto-kesselgulasch/gimp
sudo add-apt-repository ppa:ubuntuhandbook1/gimp
sudo apt update
sudo apt install gimp gmic