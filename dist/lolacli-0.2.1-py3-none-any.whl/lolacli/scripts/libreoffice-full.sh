sudo add-apt-repository ppa:libreoffice/ppa
sudo apt update

apt upgrade

sudo apt install libreoffice -y