sudo add-apt-repository ppa:stellarium/stellarium-releases
sudo apt update
sudo apt install stellarium