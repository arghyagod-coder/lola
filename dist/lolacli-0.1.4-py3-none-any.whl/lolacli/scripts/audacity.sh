apt update;
apt install -y audacity;