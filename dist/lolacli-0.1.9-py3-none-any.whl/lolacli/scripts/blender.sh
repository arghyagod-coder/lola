apt update;
sudo apt install -y blender;
