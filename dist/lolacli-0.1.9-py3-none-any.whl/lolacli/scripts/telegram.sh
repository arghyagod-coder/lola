sudo add-apt-repository ppa:atareao/telegram
sudo apt update
sudo apt install -f telegram