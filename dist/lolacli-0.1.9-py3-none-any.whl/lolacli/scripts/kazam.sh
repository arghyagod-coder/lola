sudo add-apt-repository ppa:sylvain-pineau/kazam
sudo apt-get update
sudo apt install kazam
sudo apt install python3-cairo python3-xlib
