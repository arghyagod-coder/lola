sudo add-apt-repository ppa:achadwick/mypaint-testing
sudo apt-get update
sudo apt-get install mypaint -y
