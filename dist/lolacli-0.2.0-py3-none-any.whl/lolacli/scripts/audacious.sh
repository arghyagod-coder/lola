add-apt-repository ppa:nilarimogard/webupd8;
apt update;
apt install -y audacious audacious-plugins;