## LOLA
`lola` : A simple CLI for installing packages on Linux easily 

[![GitHub license](https://github.com/arghyagod-coder/lola/blob/master/LICENSE)


#### Dependencies
+ click

