echo "Install the gdesktopsuite-0.2.1.x86_64.deb file from the opening website"
wget https://raw.githubusercontent.com/alexkim205/G-Desktop-Suite/releases/download/v0.3.1/G-Desktop-Suite-0.3.1.deb
gdebi gdesktopsuite_0.3.1_.amd64.deb

