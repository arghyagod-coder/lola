cd ~/Downloads;
curl -L https://calibre-ebook.com/dist/src | tar xvJ
cd calibre* && sudo python3 setup.py install