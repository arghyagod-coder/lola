wget https://go.skype.com/skypeforlinux-64.deb

sudo apt install ./skypeforlinux-64.deb

sudo apt update
sudo apt upgrade