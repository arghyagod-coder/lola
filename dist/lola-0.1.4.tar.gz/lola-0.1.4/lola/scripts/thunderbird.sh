sudo add-apt-repository ppa:mozillateam/ppa
sudo apt-get update
sudo apt install thunderbird