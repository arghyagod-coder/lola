cd ~/Downloads
wget https://download1.rstudio.org/desktop/bionic/amd64/rstudio-1.4.1106-amd64.deb
sudo gdebi rstudio-1.4.1106-amd64.deb
