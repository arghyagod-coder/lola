sudo add-apt-repository ppa:ubuntu-desktop/ppa
sudo apt update
sudo apt install shotwell
