cd ~/Downloads
wget https://download.jetbrains.com/python/pycharm-community-2019.3.tar.gz
tar xvf pycharm-community-2019.3.tar.gz
cd pycharm-community-2019.3
bash bin/pycharm.sh
