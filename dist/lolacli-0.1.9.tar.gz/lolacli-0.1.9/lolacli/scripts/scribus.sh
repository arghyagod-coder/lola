sudo add-apt-repository ppa:scribus/ppa
sudo apt update
sudo apt install scribus