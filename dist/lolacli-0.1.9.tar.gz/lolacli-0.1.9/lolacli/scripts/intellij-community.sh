sudo add-apt-repository ppa:mmk2410/intellij-idea-community
sudo apt update
sudo apt install intellij-idea-community
