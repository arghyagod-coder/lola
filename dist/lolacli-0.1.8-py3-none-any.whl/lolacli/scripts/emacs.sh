add-apt-repository ppa:kelleyk/emacs
apt-get update
apt install -y emacs26
